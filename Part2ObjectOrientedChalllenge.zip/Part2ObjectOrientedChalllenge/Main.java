 import java.util.Arrays;
 import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan=new Scanner(System.in);
        System.out.println("Welcome to Java Drinks");
        Item[][] items=new Item[][]{
            {new Item("Pepsi",1.99,3),new Item("Coke",2.99,1),new Item("Pepsi",4.79,8)},
            {new Item("Malt",6.80,10),new Item("Vita Milk",11.50,9), new Item("Almond Milk",20.99,15)},
            {new Item("Wheat drink",7.80,6),new Item("Kalyppo",2.50,4), new Item("Aloe Vera Drink",20.50,20)},
        };

        System.out.print("Pick a row: "); 
        // pick up row.
        int pickRow=scan.nextInt(); 
        System.out.print("Pick a spot in the row: "); 
        // pick up spot.
        int pickSpot=scan.nextInt();




        VendingMachine vendingMachine=new VendingMachine(items);
        System.out.println(vendingMachine.getItem(pickRow, pickSpot));
        vendingMachine.dispense(pickRow, pickSpot);
        System.out.println(vendingMachine.getItem(pickRow,pickSpot));

     Item item=vendingMachine.getItem(pickRow, pickSpot);
    while(item.getQuantity() != 0){
        // System.out.println("\nSorry,we are out of this"+vendingMachine.getItem(pickRow,pickSpot));
        System.out.println("Enjoy your drink! Press 1 to purchase another: "+vendingMachine.getItem(pickRow, pickSpot));
        int anotherOption=scan.nextInt();
        if(anotherOption != 1){
            System.out.println("Please enter 1");
            continue;
        }
       
        System.out.println("Pick row number");
        pickRow=scan.nextInt();
        System.out.println("Pick spot number");
        pickSpot=scan.nextInt();
       
        System.out.println(vendingMachine.getItem(pickRow, pickSpot));
        System.out.println(vendingMachine.dispense(pickRow, pickSpot));
        
        if(item.getQuantity() == 0){
            System.out.println("\nSorry,we are out of this"+vendingMachine.getItem(pickRow,pickSpot));
        }else{
            continue;
        }
        break;
    
    }
   
        // vendingMachine.dispense(0,0);
        // vendingMachine.dispense(0, 0);
        // System.out.println(vendingMachine.getItem(0, 0));
        //System.out.println(vendingMachine.getItem(2, 1));
        // Item item=vendingMachine.getItem( 2,1);
        // item.setPrice(2.99);
        // vendingMachine.setItem(item, 2, 1);
        // System.out.println(vendingMachine.getItem(2,1));
    }


    }
