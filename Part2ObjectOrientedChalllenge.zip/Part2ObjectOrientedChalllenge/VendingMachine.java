import java.util.Arrays;

public class VendingMachine{
    private Item[][] items;

    public VendingMachine(Item[][] items){
       this.items=new Item[items.length][items[0].length];
       // this.items=new Item[3][9];           
       for (int i = 0; i < items.length; i++) {
           for (int j = 0; j < items[i].length; j++) {
               this.items[i][j]=new Item(items[i][j]);
           }
       }
    }
    //getter
    public Item getItem(int row,int spot){
        return new Item(this.items[row][spot]);
    }
    //setter
    public void setItem(Item item,int row,int spot){
        this.items[row][spot]=new Item(item);
    }
    //action
    public boolean dispense(int row,int spot){
        if(this.items[row][spot].getQuantity() > 0){
            this.items[row][spot].setQuantity(this.items[row][spot].getQuantity() - 1);
            return true;
        }
        return false;
    }
    //toString
    public String toString(){
        String temp="";
        for (int i = 0; i < items.length; i++) {
            temp += "\t";
            for (int j = 0; j < items.length; j++) {
               temp += this.items[i][j].toString();
            }
            temp += "\n\n";
        }
        return temp;
    }

    // public void Calculation(int pickRow,int pickSpot){

    // }
    

}
