import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        System.out.println("Welcome to Java Drinks");
        Item[] items=new Item[]{
            new Item("Pepsi",1.99,3),
            new Item("Coke",2.99,1),
            new Item("Pepsi",4.79,8),
            new Item("Malt",6.80,10),
            new Item("Vita Milk",11.50,9),
            new Item("Almond Milk",20.99,15),
            new Item("Wheat drink",7.80,6),
            new Item("Kalyppo",2.50,4),
            new Item("Aloe Vera Drink",20.50,20),
        };

        VendingMachine vendingMachine=new VendingMachine();
        for (int i = 0; i < items.length; i++) {
            vendingMachine.setItem(items[i], i);
            if(items[i].getQuantity() >=9){
                System.out.print(items[i].toString());
            }
     
        
    }
     }
    
}
