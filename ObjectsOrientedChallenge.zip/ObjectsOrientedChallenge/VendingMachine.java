public class VendingMachine{
    private Item[] items;

    public VendingMachine(){
        this.items=new Item[9];
    }
    //getter
    public Item getItem(int index){
        return new Item(this.items[index]);
    }
    //setter
    public void setItem(Item item,int index){
        this.items[index]=new Item(item);
    }

}