import java.util.ArrayList;
import java.util.Scanner;
import java.io.File;

public class Main {
    public static void main(String[] args) throws  Exception{

         System.out.println("Welcome to Hangman!");
        
         File wordsbook = new File("/Users/akosuamaxine/JAVA/JavaPro/wordsbook.txt");

         Scanner wordsScanner = new Scanner(wordsbook);
         Scanner userInput = new Scanner(System.in);


         ArrayList<String> words = new ArrayList<>();

        while( wordsScanner.hasNextLine()) {
            words.add(wordsScanner.nextLine());
        }

        String guessWord = words.get((int)(Math.random() * words.size()));

        char[] textArray = guessWord.toCharArray();

        char[] userGuess = new char[textArray.length];
        for(int i = 0; i < textArray.length; i++) {
            userGuess[i] = '_';
        }

        boolean finished = false;
        int chances = 7;

        while( finished != true ) {
            System.out.println(" ******************************************");
            System.out.println("Please guess a letter of the unkown word");

            String letter = userInput.next();
            while(letter.length() != 1 || Character.isDigit(letter.charAt(0))) {
               System.out.println("Wrong letter guessed - Try Again"); 

               letter = userInput.next();
            }
            
            boolean checkGuessedWord = false;
            for(int i = 0; i < textArray.length; i++) {
                if (letter.charAt(0) == textArray[i]) {
                    userGuess[i] = textArray[i];
                    checkGuessedWord = true;
                }
            }
            if(!checkGuessedWord) {
                chances--;

                System.out.println("OOps! wrong letter");
            }

            boolean done = true;
            for (int i = 0; i < userGuess.length; i++) {
                if( userGuess[i] == '_') {
                    System.out.print("_");

                    done = false;

                }
                else {
                    System.out.print(" " + userGuess[i]);
                }
            }
            System.out.println("\n" + "Chances left: "+ chances);
            drawHangman(chances);

            if(done) {
                System.out.println("Wow, You guessed the word right!");
                finished = true;
            }

            if(chances <= 0) {
                System.out.println("Sorry, Game OVER");
                finished = true;
            }
        }
    }
    public static void drawHangman(int c) {
        if(c == 7) {
         System.out.println("|----------");
         System.out.println("|");
         System.out.println("|");
         System.out.println("|");
         System.out.println("|");
         System.out.println("|");
         System.out.println("|");
        }
        else if(c == 6) {
         System.out.println("|----------");
         System.out.println("|    O");
         System.out.println("|");
         System.out.println("|");
         System.out.println("|");
         System.out.println("|");
         System.out.println("|");
        }
        else if(c == 5) {
         System.out.println("|----------");
         System.out.println("|    O");
         System.out.println("|    |");
         System.out.println("|");
         System.out.println("|");
         System.out.println("|");
         System.out.println("|");
        }
        else if(c == 4) {
         System.out.println("|----------");
         System.out.println("|    O");
         System.out.println("|   -|");
         System.out.println("|");
         System.out.println("|");
         System.out.println("|");
         System.out.println("|");
        }
        else if(c == 3) {
         System.out.println("|----------");
         System.out.println("|    O");
         System.out.println("|   -|-");
         System.out.println("|");
         System.out.println("|");
         System.out.println("|");
         System.out.println("|");
        }
        else if(c == 2) {
         System.out.println("|----------");
         System.out.println("|    O");
         System.out.println("|   -|-");
         System.out.println("|   /");
         System.out.println("|");
         System.out.println("|");
         System.out.println("|");
        }
        else if(c == 1) {
         System.out.println("|----------");
         System.out.println("|    O");
         System.out.println("|   -|-");
         System.out.println("|   /|");
         System.out.println("|");
         System.out.println("|");
         System.out.println("|");
        }
        else{
            System.out.println("|----------");
         System.out.println("|    O");
         System.out.println("|   -|-");
         System.out.println("|   /| |");
         System.out.println("|");
         System.out.println("|");
         System.out.println("|");

        }
    }
}
